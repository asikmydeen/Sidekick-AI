console.log("Content script loaded"),document.body.style.border="5px solid #ff0000";
