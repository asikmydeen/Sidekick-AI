// content.js
// This script runs in the context of web pages

console.log("Content script loaded");

// Example: change background color of page
document.body.style.border = "5px solid #ff0000";